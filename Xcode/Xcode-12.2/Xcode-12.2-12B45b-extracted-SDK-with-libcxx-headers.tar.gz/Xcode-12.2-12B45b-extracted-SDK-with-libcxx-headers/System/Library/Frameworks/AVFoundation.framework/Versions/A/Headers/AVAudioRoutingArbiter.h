/*
	File:           AVAudioRoutingArbiter.h
	Framework:      AVFoundation
	
	Copyright 2020 Apple Inc. All rights reserved.
*/

#if __has_include(<AVFAudio/AVAudioRoutingArbiter.h>)
#import <AVFAudio/AVAudioRoutingArbiter.h>
#endif
